package kemne_jai;

import java.awt.BorderLayout;
import java.sql.DriverManager;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminLogin extends JFrame {

	
	String url="jdbc:mysql://localhost:3306/data";
	String user ="root";
	String pass="2468";
	String driver="com.mysql.jdbc.Driver";
	ResultSet r=null;
	PreparedStatement st=null;
	
	
	private JPanel contentPane;
	private JTextField txtUsernmae;
	private JPasswordField passwordField;
    protected Cursor cursor;
    private JLabel label;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public void cursors() {
		
		cursor = new Cursor(cursor.HAND_CURSOR);
	}
	
	public AdminLogin() {
		
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 150, 449, 571);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(211, 211, 211));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtUsernmae = new JTextField();
		txtUsernmae.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				txtUsernmae.setText("");
			}
		});
		txtUsernmae.setToolTipText("Username");
		txtUsernmae.setText("Username");
		txtUsernmae.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtUsernmae.setBounds(128, 280, 200, 49);
		contentPane.add(txtUsernmae);
		txtUsernmae.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.BOLD, 16));
		passwordField.setToolTipText("enter correct password");
		passwordField.setBounds(128, 357, 200, 49);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("CLEAR");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
				txtUsernmae.setText("");
				passwordField.setText("");
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(54, 441, 89, 34);
		btnNewButton.setCursor(cursor);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				first fs=new first();
				fs.setVisible(true);
				
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(335, 441, 89, 34);
		btnNewButton_1.setCursor(cursor);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("LOGIN");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				String un=txtUsernmae.getText();
				String pas=passwordField.getText();
			
				
				Class.forName(driver);
				Connection con=DriverManager.getConnection(url, user, pass);
				
				Statement s1=con.createStatement();
				
				String s="select * from admin where username='"+un+"' and password='"+pas+"' ";
				
				r=s1.executeQuery(s);
				
				if(r.next()) {
					
					 dispose();
					AllAdmin ad=new AllAdmin();
					ad.setVisible(true);
				
				}
				
				else {
				       
					
					
					JOptionPane.showMessageDialog(null, "YOUR USENAME OR PASSWORD IS INCORRECT", "WARNING", 1);
					
				}
				
				}
				
				catch(Exception e1) {
					System.out.println("Exception Caught"+e1);
				}
				
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(191, 441, 89, 34);
		btnNewButton_2.setCursor(cursor);
		contentPane.add(btnNewButton_2);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(first.class.getResource("/login.png")));
		label.setBounds(128, 56, 200, 175);
		contentPane.add(label);
	}
}
