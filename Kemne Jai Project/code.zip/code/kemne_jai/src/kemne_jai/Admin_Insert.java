package kemne_jai;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JToggleButton;

public class Admin_Insert extends JFrame {
	private Cursor cursor;

	private JPanel contentPane;
	private JTextField txtBusName;
	private JTextField txtFare;
	private JTextField txtBusName_2;
	private JTextField txtFare_2;
	private JTextField txtBusName_3;
	private JTextField txtFare_3;
	private JTextField txtBusName_1;
	private JTextField txtFare_1;
	private JTextField txtBusName_4;
	private JTextField txtFare_4;
	private JTextField txtBusName_5;
	private JTextField txtFare_5;
	private JTextField txtEnterAnyRandom;
	private JLabel lblNewLabel_4;

	/**
	 * Launch the application.
	 */	public void cursors() {
		
		 cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Insert frame = new Admin_Insert();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_Insert() {
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 100, 730, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("From");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(126, 23, 74, 26);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("To");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(331, 23, 65, 26);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Barguna", "Barisal","Bhola", "Bandarban","Brahmanbaria","Bagerhat","Bogra",
				
				"Chandpur", "Chittagong", "Comilla",    "Coxs Bazar","Chuadanga","Chapainawabganj","Dinajpur","Dhaka","Faridpur","Feni","Gazipur",  "Gopalganj","Gaibandha","Habiganj",
				
				 "Jhalokati", "Jessore",  "Jhenaidah","Jamalpur","Joypurhat", "Khagrachhari", "Kishoreganj","Khulna",     "Kushtia","Kurigram",
				 "Lakshmipur","Lalmonirhat","Madaripur",  "Manikganj","Munshiganj","Magura",   "Meherpur","Mymensingh","Moulvibazar","Noakhali", "Narayanganj","Narsingdi",
				 "Narail", "Netrakona","Naogaon",    "Natore","Nilphamari","Patuakhali", "Pirojpur","Pabna", "Panchagarh","Rangamati","Rajbari",
				 "Rajshahi", "Rangpur", "Sunamganj","Sylhet", "Sirajganj","Sherpur","Satkhira","Shariatpur","Tangail","Thakurgaon",
		
		}));
		comboBox.setBounds(82, 60, 118, 34);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
	comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Barguna", "Barisal","Bhola", "Bandarban","Brahmanbaria","Bagerhat","Bogra",
				
				"Chandpur", "Chittagong", "Comilla",    "Coxs Bazar","Chuadanga","Chapainawabganj","Dinajpur","Dhaka","Faridpur","Feni","Gazipur",  "Gopalganj","Gaibandha","Habiganj",
				
				 "Jhalokati", "Jessore",  "Jhenaidah","Jamalpur","Joypurhat", "Khagrachhari", "Kishoreganj","Khulna",     "Kushtia","Kurigram",
				 "Lakshmipur","Lalmonirhat","Madaripur",  "Manikganj","Munshiganj","Magura",   "Meherpur","Mymensingh","Moulvibazar","Noakhali", "Narayanganj","Narsingdi",
				 "Narail", "Netrakona","Naogaon",    "Natore","Nilphamari","Patuakhali", "Pirojpur","Pabna", "Panchagarh","Rangamati","Rajbari",
				 "Rajshahi", "Rangpur", "Sunamganj","Sylhet", "Sirajganj","Sherpur","Satkhira","Shariatpur","Tangail","Thakurgaon",
		
		}));
		comboBox_1.setBounds(302, 60, 118, 34);
		contentPane.add(comboBox_1);
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.setCursor(cursor);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
				
				try {
					
					
					
					int choice =JOptionPane.showConfirmDialog(null,"Do you want to save ?","CONFIRM", JOptionPane.YES_NO_OPTION);
					
					if(choice ==JOptionPane.YES_OPTION) {
						
						

						
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "2468");
						
			
						
						String w=txtEnterAnyRandom.getText();
						String k1=comboBox.getSelectedItem().toString();
						String k2=comboBox_1.getSelectedItem().toString();
						
						  Statement kk=con.createStatement();
						  String kw="select *  from travel where `from`='"+k1+"' and `to`= '"+k2+"' or `from`= '"+k2+"' and `to`='"+k1+"'" ;
						  ResultSet kl=kk.executeQuery(kw);
						  
						  if(kl.next()) {
				        	 
							  JOptionPane.showMessageDialog(null, "You have already added this information", "Warning", 1);
				        	  
				           }
				           
						 
						  else {
						
						 
							
						 String sql = "insert into travel(`from`,`to`,`distance`) values(?,?,?)";
						 PreparedStatement pstmt = con.prepareStatement(sql);
						 
						pstmt.setString(1,comboBox.getSelectedItem().toString());
							  pstmt.setString(2,comboBox_1.getSelectedItem().toString());
							  pstmt.setString(3,txtEnterAnyRandom.getText());
						  pstmt.execute();
						  
						  
						  Statement sk=con.createStatement();
						  String k="select id  from travel where `from`='"+k1+"' and `to`= '"+k2+"' or `from`= '"+k2+"' and `to`='"+k1+"'" ;
						  ResultSet rk=sk.executeQuery(k);
						  
						  if(rk.next()) {
				        	 String   c=rk.getString("id");
				        	 System.out.println("Number is "+c);
				        	  
				           }
				           
						  
						  
						
						
							String sql1 = "insert into ac(`bus_name`,`fare`,`id`) values(?,?,?)";
						 PreparedStatement pstmt1 = con.prepareStatement(sql1);
						 pstmt1.setString(1,txtBusName.getText());
						 pstmt1.setString(2,txtFare.getText());	 
						 pstmt1.setString(3,rk.getString("id"));	
						 pstmt1.execute();
						 
						 if(txtBusName_2.getText().isEmpty() || txtFare_2.getText().isEmpty()) {
								
								
								
								
							
								
								
								
								
								
							}
						 
						 
						 else {
							 
							 
							 
							 
							 String dql1 = "insert into ac(`bus_name`,`fare`,`id`) values(?,?,?)";
							 PreparedStatement dstmt1 = con.prepareStatement(dql1);
							 dstmt1.setString(1,txtBusName_2.getText());
							 dstmt1.setString(2,txtFare_2.getText());	 
							 dstmt1.setString(3,rk.getString("id"));	
							 dstmt1.execute();
								
							 
							 
							 
							 
							 
						 }
						 
						 
						 if(txtBusName_3.getText().isEmpty() || txtFare_3.getText().isEmpty()) {
								
								
								
								
								
								
								
								
								
								
							}
						 
						 
						 else {
							 
							 
							 
							 
							 String eql1 = "insert into ac(`bus_name`,`fare`,`id`) values(?,?,?)";
							 PreparedStatement estmt1 = con.prepareStatement(eql1);
							 estmt1.setString(1,txtBusName_3.getText());
							 estmt1.setString(2,txtFare_3.getText());	 
							 estmt1.setString(3,rk.getString("id"));	
							 estmt1.execute();
								
							 
							 
							 
							 
							 
						 }
						 
						 
						 
						 
						 
						 String sql2 = "insert into non_ac(`bus_name`,`fare`,`id`) values(?,?,?)";
						 PreparedStatement pstmt2 = con.prepareStatement(sql2);
						 pstmt2.setString(1,txtBusName_1.getText());
						 pstmt2.setString(2,txtFare_1.getText());	 
						 pstmt2.setString(3,rk.getString("id"));	
						 pstmt2.execute();
						 
						 if(txtBusName_4.getText().isEmpty() || txtFare_4.getText().isEmpty()) {
								
								
								
								
								
								
								
								
								
								
							}
						 
						 
						 else {
							 
							 
							 
							 
							 String fql1 = "insert into non_ac(`bus_name`,`fare`,`id`) values(?,?,?)";
							 PreparedStatement fstmt1 = con.prepareStatement(fql1);
							 fstmt1.setString(1,txtBusName_4.getText());
							 fstmt1.setString(2,txtFare_4.getText());	 
							 fstmt1.setString(3,rk.getString("id"));	
							 fstmt1.execute();
								
							 
							 
							 
							 
							 
						 }
						 
						 
						 
						 if(txtBusName_5.getText().isEmpty() || txtFare_5.getText().isEmpty()) {
								
								
								
								
								
								
								
								
								
								
							}
						 
						 
						 else {
							 
							 
							 
							 
							 String fql1 = "insert into non_ac(`bus_name`,`fare`,`id`) values(?,?,?)";
							 PreparedStatement fstmt1 = con.prepareStatement(fql1);
							 fstmt1.setString(1,txtBusName_4.getText());
							 fstmt1.setString(2,txtFare_4.getText());	 
							 fstmt1.setString(3,rk.getString("id"));	
							 fstmt1.execute();
								
							 
							 
							 
							 
							 
						 }
						 
						 
						 
						 JOptionPane.showMessageDialog(null, "Data has been Saved","Done",1);
						 
						
						 
						 
						 
					}
						
						
					}
				}
					
					
				
					catch(Exception e1) {
						System.out.println("Exception Caught"+e1);
				}
				
				
				
				
				
				
				
				
				
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(302, 483, 105, 26);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Main Menu");
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				first f=new first();
				f.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(31, 516, 129, 34);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_2.setBounds(555, 516, 94, 26);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Back");
		btnNewButton_3.setCursor(cursor);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			dispose();
			AllAdmin aa=new AllAdmin();
			aa.setVisible(true);
				
				
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_3.setBounds(302, 520, 105, 26);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel_2 = new JLabel("AC Buses name & Fare");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(258, 125, 240, 34);
		contentPane.add(lblNewLabel_2);
		
		txtBusName = new JTextField();
		txtBusName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				txtBusName.setText("");
				
			}
		});
		txtBusName.setText("Bus Name");
		txtBusName.setBounds(88, 183, 112, 30);
		contentPane.add(txtBusName);
		txtBusName.setColumns(10);
		
		txtFare = new JTextField();
		txtFare.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				txtFare.setText("");
			}
		});
		txtFare.setText("Fare");
		txtFare.setBounds(88, 224, 112, 26);
		contentPane.add(txtFare);
		txtFare.setColumns(10);
		
		txtBusName_2 = new JTextField();
		txtBusName_2.setToolTipText("Bus Name");
		txtBusName_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_2.setText("");
				
			}
		});
		txtBusName_2.setBounds(292, 183, 104, 30);
		contentPane.add(txtBusName_2);
		txtBusName_2.setColumns(10);
		
		txtFare_2 = new JTextField();
		txtFare_2.setToolTipText("Fare");
		txtFare_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_2.setText("");
			}
		});
		txtFare_2.setBounds(292, 224, 104, 26);
		contentPane.add(txtFare_2);
		txtFare_2.setColumns(10);
		
		txtBusName_3 = new JTextField();
		txtBusName_3.setToolTipText("Bus Name");
		txtBusName_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_3.setText("");
			}
		});
		txtBusName_3.setBounds(457, 183, 112, 26);
		contentPane.add(txtBusName_3);
		txtBusName_3.setColumns(10);
		
		txtFare_3 = new JTextField();
		txtFare_3.setToolTipText("Fare");
		txtFare_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_3.setText("");
				
			}
		});
		txtFare_3.setBounds(457, 224, 112, 26);
		contentPane.add(txtFare_3);
		txtFare_3.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Non_AC Buses Name & Fare");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(237, 315, 306, 26);
		contentPane.add(lblNewLabel_3);
		
		txtBusName_1 = new JTextField();
		txtBusName_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_1.setText("");
			}
		});
		txtBusName_1.setText("Bus Name");
		txtBusName_1.setBounds(82, 368, 86, 20);
		contentPane.add(txtBusName_1);
		txtBusName_1.setColumns(10);
		
		txtFare_1 = new JTextField();
		txtFare_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_1.setText("");
			}
		});
		txtFare_1.setText("Fare");
		txtFare_1.setBounds(82, 411, 86, 20);
		contentPane.add(txtFare_1);
		txtFare_1.setColumns(10);
		
		txtBusName_4 = new JTextField();
		txtBusName_4.setToolTipText("Bus Name");
		txtBusName_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_4.setText("");
			}
		});
		txtBusName_4.setBounds(292, 368, 86, 20);
		contentPane.add(txtBusName_4);
		txtBusName_4.setColumns(10);
		
		txtFare_4 = new JTextField();
		txtFare_4.setToolTipText("Fare");
		txtFare_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_4.setText("");
				
			}
		});
		txtFare_4.setBounds(292, 411, 86, 20);
		contentPane.add(txtFare_4);
		txtFare_4.setColumns(10);
		
		txtBusName_5 = new JTextField();
		txtBusName_5.setToolTipText("Bus Name");
		txtBusName_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_5.setText("");
			}
		});
		txtBusName_5.setBounds(457, 368, 86, 20);
		contentPane.add(txtBusName_5);
		txtBusName_5.setColumns(10);
		
		txtFare_5 = new JTextField();
		txtFare_5.setToolTipText("Fare");
		txtFare_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_5.setText("");
			}
		});
		txtFare_5.setBounds(457, 411, 86, 20);
		contentPane.add(txtFare_5);
		txtFare_5.setColumns(10);
		
		txtEnterAnyRandom = new JTextField();
		txtEnterAnyRandom.setToolTipText("use only kilometer");
		txtEnterAnyRandom.setBounds(474, 64, 110, 27);
		contentPane.add(txtEnterAnyRandom);
		txtEnterAnyRandom.setColumns(10);
		
		lblNewLabel_4 = new JLabel("Distance");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(475, 23, 94, 27);
		contentPane.add(lblNewLabel_4);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(319, 449, -48, 20);
		contentPane.add(textArea);
	}
}
