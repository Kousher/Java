package kemne_jai;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Admin_Delete extends JFrame {

	private JPanel contentPane;
	private Cursor cursor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Delete frame = new Admin_Delete();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

	/**
	 * Create the frame.
	 */
	public void cursors() {
		
		 cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
	public Admin_Delete() {
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 200, 550, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("From");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(123, 75, 74, 26);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("To");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(319, 75, 65, 26);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Barguna", "Barisal","Bhola", "Bandarban","Brahmanbaria","Bagerhat","Bogra",
				
				"Chandpur", "Chittagong", "Comilla",    "Coxs Bazar","Chuadanga","Chapainawabganj","Dinajpur","Dhaka","Faridpur","Feni","Gazipur",  "Gopalganj","Gaibandha","Habiganj",
				
				 "Jhalokati", "Jessore",  "Jhenaidah","Jamalpur","Joypurhat", "Khagrachhari", "Kishoreganj","Khulna",     "Kushtia","Kurigram",
				 "Lakshmipur","Lalmonirhat","Madaripur",  "Manikganj","Munshiganj","Magura",   "Meherpur","Mymensingh","Moulvibazar","Noakhali", "Narayanganj","Narsingdi",
				 "Narail", "Netrakona","Naogaon",    "Natore","Nilphamari","Patuakhali", "Pirojpur","Pabna", "Panchagarh","Rangamati","Rajbari",
				 "Rajshahi", "Rangpur", "Sunamganj","Sylhet", "Sirajganj","Sherpur","Satkhira","Shariatpur","Tangail","Thakurgaon",}));
		comboBox.setBounds(99, 123, 118, 34);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Barguna", "Barisal","Bhola", "Bandarban","Brahmanbaria","Bagerhat","Bogra",
				
				"Chandpur", "Chittagong", "Comilla",    "Coxs Bazar","Chuadanga","Chapainawabganj","Dinajpur","Dhaka","Faridpur","Feni","Gazipur",  "Gopalganj","Gaibandha","Habiganj",
				
				 "Jhalokati", "Jessore",  "Jhenaidah","Jamalpur","Joypurhat", "Khagrachhari", "Kishoreganj","Khulna",     "Kushtia","Kurigram",
				 "Lakshmipur","Lalmonirhat","Madaripur",  "Manikganj","Munshiganj","Magura",   "Meherpur","Mymensingh","Moulvibazar","Noakhali", "Narayanganj","Narsingdi",
				 "Narail", "Netrakona","Naogaon",    "Natore","Nilphamari","Patuakhali", "Pirojpur","Pabna", "Panchagarh","Rangamati","Rajbari",
				 "Rajshahi", "Rangpur", "Sunamganj","Sylhet", "Sirajganj","Sherpur","Satkhira","Shariatpur","Tangail","Thakurgaon",}));
		comboBox_1.setBounds(281, 123, 118, 34);
		contentPane.add(comboBox_1);
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.setCursor(cursor);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				

				try {
					
					
					
					int choice =JOptionPane.showConfirmDialog(null,"Do you want to Delete ?","CONFIRM", JOptionPane.YES_NO_OPTION);
					
					if(choice ==JOptionPane.YES_OPTION) {
						
						

						
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "2468");
						
			
						
						
						String k1=comboBox.getSelectedItem().toString();
						String k2=comboBox_1.getSelectedItem().toString();
						
						  Statement kk=con.createStatement();
						  String kw="select *  from travel where `from`='"+k1+"' and `to`= '"+k2+"' or `from`= '"+k2+"' and `to`='"+k1+"'" ;
						  ResultSet kl=kk.executeQuery(kw);
				
				
				          if(kl.next()) {
				        	  
				        	  String   f=kl.getString("id");
				        	  
				        	  
				        	  String z1="delete   from travel where id='"+f+"'  " ;
								
								Statement stb=(Statement) con.createStatement();
								
								stb.executeUpdate(z1);  
								
								
								 String z2="delete   from ac where id='"+f+"'  " ;
									
									Statement stb2=(Statement) con.createStatement();
									
									 
									stb2.executeUpdate(z2); 
				        	  
                                     String z3="delete  from non_ac where id='"+f+"'  " ;
									
									Statement stb3=(Statement) con.createStatement();
									
									stb3.executeUpdate(z3); 
				        	  
				        	  
									 JOptionPane.showMessageDialog(null, "You Delete Successfully the information", "Warning", 1);
				        	  
				        	  
				        	  
				        	  
				          }
				
				          else {
				        	  
				        	  JOptionPane.showMessageDialog(null, "You want to delete wrong information", "Warning", 1);
				          }
				
					}
					
				}
				
				catch(Exception e1) {
				System.out.println("Exception caught in"+e1);	
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(217, 255, 104, 34);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Main Menu");
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				first f=new first();
				f.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(23, 255, 137, 34);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_2.setBounds(382, 255, 104, 34);
		contentPane.add(btnNewButton_2);
	}
}
	
