package kemne_jai;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

public class AllAdmin extends JFrame {

	private JPanel contentPane;
    private Cursor cursor;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AllAdmin frame = new AllAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void cursors() {
		
		 cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
	public AllAdmin() {
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 150, 653, 259);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.setCursor(cursor);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				Admin_Insert ai=new Admin_Insert();
				ai.setVisible(true);
			}
		});
		btnNewButton.setBounds(29, 107, 102, 38);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Admin_Update au=new Admin_Update();
				au.setVisible(true);
				
			}
		});
		btnNewButton_1.setBounds(194, 107, 102, 38);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				Admin_Delete ad=new Admin_Delete();
				ad.setVisible(true);
				
				
			}
		});
		btnNewButton_2.setBounds(348, 108, 102, 37);
		contentPane.add(btnNewButton_2);
		
		JButton btnBack = new JButton("Back");
		btnBack.setCursor(cursor);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				first ft = new first();
				ft.setVisible(true);
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.setBounds(496, 107, 102, 38);
		contentPane.add(btnBack);
		
		JLabel lblKemneJai = new JLabel("Kemne Jai");
		lblKemneJai.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblKemneJai.setBounds(234, 11, 195, 37);
		contentPane.add(lblKemneJai);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(first.class.getResource("/delete.png")));
		label.setBounds(0, 0, 637, 220);
		contentPane.add(label);
	}

}
