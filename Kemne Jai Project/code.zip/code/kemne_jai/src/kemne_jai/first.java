package kemne_jai;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class first extends JFrame {

	private JPanel contentPane;
    private Cursor cursor;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					first frame = new first();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void cursors() {
		
		 cursor=new Cursor(cursor.HAND_CURSOR);
		
	}

	
	public first() {
		
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 200, 657, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(32, 178, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome To Kemne Jai ");
		lblNewLabel.setForeground(new Color(173, 216, 230));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setBounds(137, 0, 380, 79);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_1 = new JButton("User Login");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				userlogin au=new userlogin();
				au.setVisible(true);
				
			}
		});
		btnNewButton_1.setToolTipText("For User");
		btnNewButton_1.setForeground(new Color(25, 25, 112));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(56, 150, 144, 55);
		btnNewButton_1.setCursor(cursor);
		
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Admin Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				AdminLogin adminlogin =new AdminLogin();
				adminlogin.setVisible(true);
				
				
			}
		});
		btnNewButton.setToolTipText("For Admin Login");
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(231, 236, 144, 55);
		btnNewButton.setCursor(cursor);
		contentPane.add(btnNewButton);
		
		JButton signup = new JButton("User Sign up");
		signup.setCursor(cursor);
		signup.setForeground(new Color(25, 25, 112));
		signup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			
				dispose();
				adduser ad = new adduser();
				ad.setVisible(true);
			}
		});
		signup.setFont(new Font("Tahoma", Font.BOLD, 14));
		signup.setBounds(408, 150, 137, 55);
		contentPane.add(signup);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(first.class.getResource("/welcome.png")));
		label.setBounds(0, 0, 641, 361);
		contentPane.add(label);
		
	}
}
