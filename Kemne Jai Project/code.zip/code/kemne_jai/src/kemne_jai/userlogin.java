package kemne_jai;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class userlogin extends JFrame {
	private Cursor cursor;
	
	public static String un;
	
	String url="jdbc:mysql://localhost:3306/data";
	String user ="root";
	String pass="2468";
	String driver="com.mysql.jdbc.Driver";
	ResultSet r=null;
	PreparedStatement st=null;
	

	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userlogin frame = new userlogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void cursors() {
		
		 cursor=new Cursor(cursor.HAND_CURSOR);
		
	}

	/**
	 * Create the frame.
	 */
	public userlogin() {
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 150, 422, 467);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtUsername.setText("");
				
			}
		});
		txtUsername.setText("Username");
		txtUsername.setToolTipText("Username");
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtUsername.setBounds(107, 214, 165, 50);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		JButton btnLogIn = new JButton("Log In");
		btnLogIn.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnLogIn.setCursor(cursor);
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				un=txtUsername.getText();
				String pas=passwordField.getText();
			
				
				Class.forName(driver);
				Connection con=DriverManager.getConnection(url, user, pass);
				
				Statement s1=con.createStatement();
				
				String s="select * from user where username='"+un+"' and password='"+pas+"' ";
				
				r=s1.executeQuery(s);
				
				if(r.next()) {
					
					 dispose();
					 AllUser ft = new AllUser();
					 ft.setVisible(true);
					
				
				}
				
				else {
				       
					
					 dispose();
					userlogin al=new userlogin();
					al.setVisible(true);
					JOptionPane.showMessageDialog(null, "YOUR USENAME OR PASSWORD IS INCORRECT", "WARNING", 1);
					
				}
				
				}
				
				catch(Exception e1) {
					System.out.println("Exception Caught"+e1);
				}
				
			}
		});
		btnLogIn.setBounds(64, 364, 110, 39);
		contentPane.add(btnLogIn);
		
		passwordField = new JPasswordField();
		passwordField.setToolTipText("Password");
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		passwordField.setBounds(107, 287, 165, 48);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setCursor(cursor);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				first um = new first();
				um.setVisible(true);
				
			}
		});
		btnNewButton.setBounds(213, 364, 102, 39);
		contentPane.add(btnNewButton);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(first.class.getResource("/login.png")));
		label.setBounds(95, 11, 202, 175);
		contentPane.add(label);
	}

}
