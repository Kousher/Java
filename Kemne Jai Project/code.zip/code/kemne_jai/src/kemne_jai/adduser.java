package kemne_jai;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.sun.jdi.connect.spi.Connection;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class adduser extends JFrame {
	 private Cursor cursor;

	private JPanel contentPane;
	private JTextField username;
	private JTextField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adduser frame = new adduser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void cursors() {
		
		 cursor=new Cursor(cursor.HAND_CURSOR);
		
	}

	/**
	 * Create the frame.
	 */
	public adduser() {
		cursors();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 150, 406, 453);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserName = new JLabel("User name");
		lblUserName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblUserName.setBounds(42, 204, 89, 35);
		contentPane.add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPassword.setBounds(41, 262, 100, 35);
		contentPane.add(lblPassword);
		
		username = new JTextField();
		username.setBounds(182, 206, 129, 35);
		contentPane.add(username);
		username.setColumns(10);
		
		JButton btnSignUo = new JButton("Sign Up");
		btnSignUo.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSignUo.setCursor(cursor);
		btnSignUo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					
					
					
					
					Class.forName("com.mysql.jdbc.Driver");
					java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "2468");
										
				     String sql = "insert into user values(?,?)";
				
					PreparedStatement pstmt = con.prepareStatement(sql);
					
					
					pstmt.setString(1, username.getText());
					pstmt.setString(2,password.getText() );
					
					pstmt.execute();
					
					JOptionPane.showMessageDialog(null, "Your Account has been created","Done",1);
					dispose();
					userlogin userlogin =new userlogin();
					userlogin.setVisible(true);
					
					
				}
					catch(SQLIntegrityConstraintViolationException e1) {
						JOptionPane.showMessageDialog(null, "Name Already Taken","Done",1);	
						
				}
				
				catch(Exception w) {
					
				}

				
			}
		});
		btnSignUo.setBounds(31, 341, 100, 35);
		contentPane.add(btnSignUo);
		
		password = new JTextField();
		password.setBounds(182, 264, 129, 35);
		contentPane.add(password);
		password.setColumns(10);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnBack.setCursor(cursor);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				first um = new first();
				um.setVisible(true);
				
				
				
				
			}
			
		});
		btnBack.setBounds(196, 341, 89, 35);
		contentPane.add(btnBack);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(first.class.getResource("/signup.png")));
		label.setBounds(85, 11, 200, 182);
		contentPane.add(label);
	}
	private static class __Tmp {
		private static void __tmp() {
			  javax.swing.JPanel __wbp_panel = new javax.swing.JPanel();
		}
	}
}
