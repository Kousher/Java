package kemne_jai;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JToggleButton;

public class AllUser extends JFrame {

	private JPanel contentPane;
	private JTextField txtBusName;
	private JTextField txtFare;
	private JTextField txtBusName_2;
	private JTextField txtFare_2;
	private JTextField txtBusName_3;
	private JTextField txtFare_3;
	private JTextField txtBusName_1;
	private JTextField txtFare_1;
	private JTextField txtBusName_4;
	private JTextField txtFare_4;
	private JTextField txtBusName_5;
	private JTextField txtFare_5;
	private JTextField textField;
	private JTextField tex;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AllUser frame = new AllUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AllUser() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 100, 730, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("From");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(126, 23, 74, 26);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("To");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(331, 23, 65, 26);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Barguna", "Barisal","Bhola", "Bandarban","Brahmanbaria","Bagerhat","Bogra",
				
				"Chandpur", "Chittagong", "Comilla",    "Coxs Bazar","Chuadanga","Chapainawabganj","Dinajpur","Dhaka","Faridpur","Feni","Gazipur",  "Gopalganj","Gaibandha","Habiganj",
				
				 "Jhalokati", "Jessore",  "Jhenaidah","Jamalpur","Joypurhat", "Khagrachhari", "Kishoreganj","Khulna",     "Kushtia","Kurigram",
				 "Lakshmipur","Lalmonirhat","Madaripur",  "Manikganj","Munshiganj","Magura",   "Meherpur","Mymensingh","Moulvibazar","Noakhali", "Narayanganj","Narsingdi",
				 "Narail", "Netrakona","Naogaon",    "Natore","Nilphamari","Patuakhali", "Pirojpur","Pabna", "Panchagarh","Rangamati","Rajbari",
				 "Rajshahi", "Rangpur", "Sunamganj","Sylhet", "Sirajganj","Sherpur","Satkhira","Shariatpur","Tangail","Thakurgaon",
		}));
		comboBox.setBounds(82, 60, 118, 34);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Barguna", "Barisal","Bhola", "Bandarban","Brahmanbaria","Bagerhat","Bogra",
				
				"Chandpur", "Chittagong", "Comilla",    "Coxs Bazar","Chuadanga","Chapainawabganj","Dinajpur","Dhaka","Faridpur","Feni","Gazipur",  "Gopalganj","Gaibandha","Habiganj",
				
				 "Jhalokati", "Jessore",  "Jhenaidah","Jamalpur","Joypurhat", "Khagrachhari", "Kishoreganj","Khulna",     "Kushtia","Kurigram",
				 "Lakshmipur","Lalmonirhat","Madaripur",  "Manikganj","Munshiganj","Magura",   "Meherpur","Mymensingh","Moulvibazar","Noakhali", "Narayanganj","Narsingdi",
				 "Narail", "Netrakona","Naogaon",    "Natore","Nilphamari","Patuakhali", "Pirojpur","Pabna", "Panchagarh","Rangamati","Rajbari",
				 "Rajshahi", "Rangpur", "Sunamganj","Sylhet", "Sirajganj","Sherpur","Satkhira","Shariatpur","Tangail","Thakurgaon",
		}));
		comboBox_1.setBounds(302, 60, 118, 34);
		contentPane.add(comboBox_1);
		
		JButton btnNewButton_1 = new JButton("Main Menu");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				first f=new first();
				f.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(31, 516, 129, 34);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_2.setBounds(555, 516, 94, 26);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Back");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			dispose();
			first aa=new first();
			aa.setVisible(true);
				
				
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_3.setBounds(302, 520, 105, 26);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel_2 = new JLabel("AC Buses name & Fare");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(258, 125, 240, 34);
		contentPane.add(lblNewLabel_2);
		
		txtBusName = new JTextField();
		txtBusName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				txtBusName.setText("");
				
			}
		});
		txtBusName.setText("Bus Name");
		txtBusName.setBounds(88, 183, 112, 30);
		contentPane.add(txtBusName);
		txtBusName.setColumns(10);
		
		txtFare = new JTextField();
		txtFare.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				txtFare.setText("");
			}
		});
		txtFare.setText("Fare");
		txtFare.setBounds(88, 224, 112, 26);
		contentPane.add(txtFare);
		txtFare.setColumns(10);
		
		txtBusName_2 = new JTextField();
		txtBusName_2.setToolTipText("Bus Name");
		txtBusName_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_2.setText("");
				
			}
		});
		txtBusName_2.setBounds(292, 183, 104, 30);
		contentPane.add(txtBusName_2);
		txtBusName_2.setColumns(10);
		
		txtFare_2 = new JTextField();
		txtFare_2.setToolTipText("Fare");
		txtFare_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_2.setText("");
			}
		});
		txtFare_2.setBounds(292, 224, 104, 26);
		contentPane.add(txtFare_2);
		txtFare_2.setColumns(10);
		
		txtBusName_3 = new JTextField();
		txtBusName_3.setToolTipText("Bus Name");
		txtBusName_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_3.setText("");
			}
		});
		txtBusName_3.setBounds(457, 183, 112, 26);
		contentPane.add(txtBusName_3);
		txtBusName_3.setColumns(10);
		
		txtFare_3 = new JTextField();
		txtFare_3.setToolTipText("Fare");
		txtFare_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_3.setText("");
				
			}
		});
		txtFare_3.setBounds(457, 224, 112, 26);
		contentPane.add(txtFare_3);
		txtFare_3.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Non_AC Buses Name & Fare");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(236, 282, 306, 26);
		contentPane.add(lblNewLabel_3);
		
		txtBusName_1 = new JTextField();
		txtBusName_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_1.setText("");
			}
		});
		txtBusName_1.setText("Bus Name");
		txtBusName_1.setBounds(82, 324, 105, 26);
		contentPane.add(txtBusName_1);
		txtBusName_1.setColumns(10);
		
		txtFare_1 = new JTextField();
		txtFare_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_1.setText("");
			}
		});
		txtFare_1.setText("Fare");
		txtFare_1.setBounds(82, 361, 105, 27);
		contentPane.add(txtFare_1);
		txtFare_1.setColumns(10);
		
		txtBusName_4 = new JTextField();
		txtBusName_4.setToolTipText("Bus Name");
		txtBusName_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_4.setText("");
			}
		});
		txtBusName_4.setBounds(277, 324, 105, 26);
		contentPane.add(txtBusName_4);
		txtBusName_4.setColumns(10);
		
		txtFare_4 = new JTextField();
		txtFare_4.setToolTipText("Fare");
		txtFare_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_4.setText("");
				
			}
		});
		txtFare_4.setBounds(277, 361, 105, 25);
		contentPane.add(txtFare_4);
		txtFare_4.setColumns(10);
		
		txtBusName_5 = new JTextField();
		txtBusName_5.setToolTipText("Bus Name");
		txtBusName_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBusName_5.setText("");
			}
		});
		txtBusName_5.setBounds(441, 324, 105, 24);
		contentPane.add(txtBusName_5);
		txtBusName_5.setColumns(10);
		
		txtFare_5 = new JTextField();
		txtFare_5.setToolTipText("Fare");
		txtFare_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtFare_5.setText("");
			}
		});
		txtFare_5.setBounds(441, 361, 105, 25);
		contentPane.add(txtFare_5);
		txtFare_5.setColumns(10);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(319, 449, -48, 20);
		contentPane.add(textArea);
		
		JButton btnNewButton_4 = new JButton("Search");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				try {
					
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data", "root", "2468");
					
					String a1=comboBox.getSelectedItem().toString();
					String a2=comboBox_1.getSelectedItem().toString();
					
					String z="select id,distance  from travel where `from`='"+a1+"' and `to`= '"+a2+"' or `from`= '"+a2+"' and `to`='"+a1+"'" ;
					
					Statement sta=(Statement) con.createStatement();
					
					ResultSet r=sta.executeQuery(z);
					
					
					if(r.next()) {
						
						String   f=r.getString("id");
						String d=r.getString("distance");
						
						tex.setText(d);
						
						
						
						String z1="select *  from ac where id='"+f+"'  " ;
						
						Statement stb=(Statement) con.createStatement();
						
						ResultSet rz=stb.executeQuery(z1);
						int u=0;
						while(rz.next()) {
							u++;
							
							if(u==1) {
								
								txtBusName.setText(rz.getString("bus_name"));
								txtFare.setText(rz.getString("fare"));
							}
							
							else if(u==2) {
								
								txtBusName_2.setText(rz.getString("bus_name"));
								txtFare_2.setText(rz.getString("fare"));
							}
							
                                else if(u==3) {
								
								txtBusName_3.setText(rz.getString("bus_name"));
								txtFare_3.setText(rz.getString("fare"));
							}
							
                                else {
                                	JOptionPane.showMessageDialog(null, "There are no ac bus available","Done",1);
                                }
							
							
							
							
							
						}
						
						
						
						
                         String z2="select *  from non_ac where id='"+f+"'  " ;
						
						Statement stc=(Statement) con.createStatement();
						
						ResultSet rf=stc.executeQuery(z2);
						int v=0;
						while(rf.next()) {
							v++;
							
							if(v==1) {
								
								txtBusName_1.setText(rf.getString("bus_name"));
								txtFare_1.setText(rf.getString("fare"));
							}
							
							else if(v==2) {
								
								txtBusName_4.setText(rf.getString("bus_name"));
								txtFare_4.setText(rf.getString("fare"));
							}
							
                                else if(v==3) {
								
								txtBusName_5.setText(rf.getString("bus_name"));
								txtFare_5.setText(rf.getString("fare"));
							}
							
                                else {
                                	JOptionPane.showMessageDialog(null, "There are no non_ac bus available","Done",1);
                                }
							
							
							
							
							
						}
						
						String o="select place_name  from historical where  `Dis_name`= '"+a2+"' " ;
						
						Statement stp=(Statement) con.createStatement();
						
						ResultSet tt=stp.executeQuery(o);
						
						if(tt.next()) {
							
							
							
							textField.setText(tt.getString("place_name"));
							
						}
						
						
						
						
						
						
						
						
						
						
					}
					
					else {
						
						JOptionPane.showMessageDialog(null, "You have no information","Done",1);
						
					}
						
					
					
					
					
				}
				
				
				catch(Exception e2) {
					System.out.println("Exception caught"+e2);
					
				}
				
				
				
				
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_4.setBounds(488, 58, 89, 34);
		contentPane.add(btnNewButton_4);
		
		JLabel lblNewLabel_4 = new JLabel("Historical Place");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBackground(new Color(240, 240, 240));
		lblNewLabel_4.setBounds(31, 428, 115, 37);
		contentPane.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(168, 430, 510, 33);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Distance");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(610, 183, 94, 26);
		contentPane.add(lblNewLabel_5);
		
		tex = new JTextField();
		tex.setBounds(610, 224, 94, 26);
		contentPane.add(tex);
		tex.setColumns(10);
	}
}
