import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class VotingDemo1 extends JFrame {

	private JPanel contentPane;
    protected Cursor cursor;
    String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VotingDemo1 frame = new VotingDemo1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public void cursors() {
		
		 cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
	
	
	public VotingDemo1() {
		
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 100, 800, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Welcome to Online Voting System");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setForeground(new Color(0, 0, 128));
		lblNewLabel.setBounds(139, 11, 591, 62);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_2 = new JButton("Result");
		btnNewButton_2.setBackground(new Color(224, 255, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					
					Class.forName(driver);
					Connection con=DriverManager.getConnection(url, user, pass);
				
					
					String u="1";
					Statement st=con.createStatement();
					
					
					String p="select  *from result where res='"+u+"' ";
					ResultSet r=st.executeQuery(p);
					
				if(r.next()) {
					
					
					JOptionPane.showMessageDialog(null, "Result is not Published","WARNING",JOptionPane.ERROR_MESSAGE);
				}
					
					
				else {	
				dispose();
				Result sr=new Result();
				sr.setVisible(true);
				
				}
				}
				
				catch(Exception e1) {
					System.out.println("Exception caught in "+e1);
				}
				
			}
		});
		btnNewButton_2.setForeground(new Color(25, 25, 112));
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_2.setBounds(387, 93, 137, 38);
		btnNewButton_2.setCursor(cursor);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Exit");
		btnNewButton_3.setBackground(new Color(224, 255, 255));
		btnNewButton_3.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_3.setForeground(new Color(25, 25, 112));
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_3.setBounds(562, 93, 122, 38);
		btnNewButton_3.setCursor(cursor);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.setBackground(new Color(224, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				SignupFrameSwing signupframeswing=new SignupFrameSwing();
				signupframeswing.setVisible(true);
				
			}
		});
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(235, 93, 130, 35);
		btnNewButton.setCursor(cursor);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Login");
		btnNewButton_1.setBackground(new Color(224, 255, 255));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				Frame1 frame1=new Frame1();
				frame1.setVisible(true);
				
			}
		});
		btnNewButton_1.setForeground(new Color(25, 25, 112));
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.setBounds(98, 93, 111, 38);
		btnNewButton_1.setCursor(cursor);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(VotingDemo1.class.getResource("/images/welocme.jpg")));
		lblNewLabel_1.setBounds(0, 154, 784, 307);
		contentPane.add(lblNewLabel_1);
		
	
	}
}
