import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminShowVoterSwing extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private Cursor cursor;

	String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminShowVoterSwing frame = new AdminShowVoterSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

public void cursors() {
		
		cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
private ImageIcon img1,img;
private JLabel jl;
	public AdminShowVoterSwing() {
		
		cursors();
	
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 70, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Voter List");
		lblNewLabel.setForeground(new Color(0, 0, 139));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBounds(264, 35, 167, 31);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 24, 624, 252);
		scrollPane.setBackground(Color.blue);
		contentPane.add(scrollPane);
		
	
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Show List");
		btnNewButton.setCursor(cursor);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				

				try {
					
					Class.forName(driver);
					Connection con1=DriverManager.getConnection(url, user, pass);
					
					String s1="select IdNumber,FullName,UserName,FatherName,MotherName,Age,Address,Gender from database.signup  ";
					
				Statement 	st1=con1.createStatement();
			
					
					ResultSet rs1=	st1.executeQuery(s1);
						
						table.setModel(DbUtils.resultSetToTableModel(rs1));
					
						
						
						
					} catch (Exception e1) {
						System.out.println("Exception caught "+e1);
					}
				
				
				
				
				
			}
		});
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.setBounds(248, 404, 141, 31);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				AdminSwing am=new AdminSwing();
				am.setVisible(true);
				
			}
		});
		btnNewButton_1.setForeground(new Color(25, 25, 112));
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setBounds(62, 404, 95, 31);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setForeground(new Color(25, 25, 112));
		btnNewButton_2.setBounds(460, 403, 101, 29);
		contentPane.add(btnNewButton_2);
img =new ImageIcon(getClass().getResource("bd.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(700, 500, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
	}
}
