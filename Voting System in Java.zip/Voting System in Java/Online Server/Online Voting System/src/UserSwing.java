import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class UserSwing extends VotingDemo1{

	private JPanel contentPane;
  public Cursor cursor;
  String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
  
  static String value;
	

public void cursors() {
		
		cursor=new Cursor(cursor.HAND_CURSOR);
		
	}

private ImageIcon img,img1;
private JLabel jl;

UserSwing(String id){
	
	value =id;
	
}
	UserSwing() {
		
		VotingDemo1 votee=new VotingDemo1();
		
		cursors();
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("WELCOME");
		lblNewLabel.setForeground(new Color(25, 25, 112));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setBounds(278, 31, 185, 55);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Drop Your Vote");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			try {
				
				Class.forName(driver);
				Connection con=DriverManager.getConnection(url, user, pass);
			
					
					
					Statement st2=con.createStatement();
					
					String s2="select *from vote where idvote='"+value+"' ";
					
				ResultSet	r2=st2.executeQuery(s2);
				
				if(r2.next()) {
					
					
					JOptionPane.showMessageDialog(null, "YOUR VOTE IS ALREADY COUNTED","Warning",2);
				}
				
				else {
				dispose();
				Vote vote1=new Vote();
				vote1.setVisible(true);
				}
				}
			catch(Exception e1) {
				System.out.println("Exception caught in"+e1);
			}
				
			}
		});
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setCursor(cursor);
		btnNewButton.setBounds(78, 128, 185, 38);
		contentPane.add(btnNewButton);
		
		
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0);
			}
		});
		btnNewButton_2.setForeground(new Color(25, 25, 112));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(540, 350, 105, 33);
		btnNewButton_2.setCursor(cursor);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("View Profile");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				UserProfileView upo=new UserProfileView();
				upo.setVisible(true);
				
				
			}
		});
		btnNewButton_3.setForeground(new Color(25, 25, 112));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(78, 197, 185, 38);
		btnNewButton_3.setCursor(cursor);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Change Password");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				PasswordChange ps=new PasswordChange();
				ps.setVisible(true);
				
				
			}
		});
		btnNewButton_4.setForeground(new Color(25, 25, 112));
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_4.setCursor(cursor);
		btnNewButton_4.setBackground(Color.WHITE);
		btnNewButton_4.setBounds(78, 260, 185, 38);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Log Out");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				dispose();
				votee.setVisible(true);
			}
		});
		btnNewButton_5.setForeground(new Color(25, 25, 112));
		btnNewButton_5.setCursor(cursor);
		btnNewButton_5.setBackground(Color.WHITE);
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_5.setBounds(45, 350, 123, 33);
		contentPane.add(btnNewButton_5);
img =new ImageIcon(getClass().getResource("main.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(1000, 500, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
	}
}
