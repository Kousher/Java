import java.sql.DriverManager;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.sql.*;

public class Login extends JFrame{
	
	String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
	ResultSet r=null;
	PreparedStatement st=null;
	Login(String un1,String pass1){
	try {
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url, user, pass);
		
		
		
	
		
		
	
			
			
			Statement st=con.createStatement();
			
			String s="select *from login where username='"+un1+"' and password='"+pass1+"' ";
			
			r=st.executeQuery(s);
			
			if(r.next()) {
				
			 
				AdminSwing adminswing=new AdminSwing();
				adminswing.setVisible(true);
			
			}
			
			else {
			       
				
				 
				ConfirmAdminSwing ob=new ConfirmAdminSwing();
				ob.setVisible(true);
				JOptionPane.showMessageDialog(null, "YOUR USENAME OR PASSWORD IS INCORRECT", "WARNING", 1);
				
			}
			
		
	}
	
	catch(Exception e) {
		System.out.println("Exception Caught"+e);
	}

}
	
	

}