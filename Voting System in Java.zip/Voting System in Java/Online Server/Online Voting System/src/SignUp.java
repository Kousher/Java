import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class SignUp {

	
	
	

	
	String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
	ResultSet r=null;
	PreparedStatement st=null;
	
  SignUp(String FullName,String UserName,String FatherName,String MotherName,String Age,String Address,String Gender,String Pass)
  
  
  {
	
	  
	  
	try {
		
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url, user, pass);
		
		
		String ab="insert into signup (FullName, UserName, FatherName, MotherName, Age, Address, Gender, Pass) values(?,?,?,?,?,?,?,?) ";
		
		
		st=con.prepareStatement(ab);
		
		
		
		st.setString(1,FullName);
		st.setString(2,UserName);
		st.setString(3,FatherName);
		st.setString(4,MotherName);
		st.setString(5, Age);
		st.setString(6,Address);
		st.setString(7,Gender);
		st.setString(8,Pass);
		
		st.executeUpdate();
		
		
		JOptionPane.showMessageDialog(null, "Thank You.Your Registration is Complete","Welcome",JOptionPane.INFORMATION_MESSAGE);
		
		
		
		
	}
	catch(Exception e){
		System.out.println("Exception Caught"+e);
	}
	
	
	
	
}
	
	
}


