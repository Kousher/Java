import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.naming.spi.DirStateFactory.Result;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.ImageIcon;

public class AdminSwing extends JFrame {

	private JPanel contentPane;
	private Cursor cursor;
	String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
		
			public void run() {
				try {
					AdminSwing frame = new AdminSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

public void cursors() {
		
		cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
private ImageIcon img,img1;
private JLabel jl;
	
	public AdminSwing() {
		
		
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 100, 1000, 500);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("WELCOME ADMIN");
		lblNewLabel.setForeground(new Color(0, 0, 102));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setBounds(335, 11, 317, 103);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("See Voter List");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				AdminShowVoterSwing adminShowVoterSwing =new AdminShowVoterSwing();
				adminShowVoterSwing.setVisible(true);
				
				
			}
		});
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.setBounds(51, 125, 193, 57);
		btnNewButton.setCursor(cursor);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Log Out");
		btnNewButton_1.setForeground(new Color(25, 25, 112));
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				VotingDemo1 vo=new VotingDemo1();
				vo.setVisible(true);
				
			}
		});
		btnNewButton_1.setBounds(51, 364, 148, 73);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update Voter");
		btnNewButton_2.setForeground(new Color(25, 25, 112));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				UpdateAdminSwing updateAdminSwing =new UpdateAdminSwing();
				updateAdminSwing.setVisible(true);
				
				
			}
		});
		btnNewButton_2.setBounds(303, 125, 187, 61);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Delete Voter");
		btnNewButton_3.setForeground(new Color(25, 25, 112));
		btnNewButton_3.setCursor(cursor);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				dispose();
				Alladmin alladmin=new Alladmin();
				alladmin.setVisible(true);
				
			}
		});
		btnNewButton_3.setBounds(526, 125, 181, 61);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Declare Result");
		btnNewButton_4.setForeground(new Color(25, 25, 112));
		btnNewButton_4.setCursor(cursor);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					
					
					
					
					Class.forName(driver);
					Connection con=DriverManager.getConnection(url, user, pass);
					
					String i="2";
					
                  Statement st4=(Statement) con.createStatement();
					
					String s4="select *from result where res='"+i+"' ";
					
				ResultSet	rs4=st4.executeQuery(s4);
					
				
					if(rs4.next()) {
						JOptionPane.showMessageDialog(null, "YOU ALREADY DECLARED RESULT","WARNING",JOptionPane.ERROR_MESSAGE);
					}
					
					else {
					String ad="update  result set res='"+i+"' ";
					
					Statement 	st3=(Statement) con.createStatement();
					
					
					 st3.executeUpdate(ad);
					
					
					
					JOptionPane.showMessageDialog(null, "Thank You.Now You Can See the Result","Welcome",JOptionPane.INFORMATION_MESSAGE);
					
				}
				}
				
				catch(Exception e3) {
					
					System.out.println("Exception caught in"+e3);
				}
				
				
			}
		});
		btnNewButton_4.setBounds(767, 127, 207, 57);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Counting Voter List");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Class.forName(driver);
					Connection con1=DriverManager.getConnection(url, user, pass);
					
					String a="select count(IdNumber) from database.signup";
					
					
					Statement st5=(Statement) con1.createStatement();
					
					ResultSet rs5=	st5.executeQuery(a);
					
					
					
					if(rs5.next()) {
						
						String c=rs5.getString("count(IdNumber)");
						JOptionPane.showMessageDialog(null,"Total Voter is   "+c,"Counter",JOptionPane.PLAIN_MESSAGE );
						
						
					}
					
				}
				catch(Exception e4) {
					
					System.out.println("Exception caught in"+e4);
				}
				
				
			}
		});
		btnNewButton_5.setForeground(new Color(25, 25, 112));
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_5.setCursor(cursor);
		btnNewButton_5.setBounds(145, 234, 256, 58);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Search a Voter");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				AdminVoterSearch adminVoterSearch =new AdminVoterSearch();
				adminVoterSearch.setVisible(true);
				
				
				
				
			}
		});
		btnNewButton_6.setForeground(new Color(25, 25, 112));
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_6.setCursor(cursor);
		btnNewButton_6.setBounds(621, 231, 242, 61);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Exit");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0);
			}
		});
		btnNewButton_7.setForeground(new Color(25, 25, 112));
		btnNewButton_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_7.setCursor(cursor);
		
		btnNewButton_7.setBounds(822, 362, 139, 77);
		contentPane.add(btnNewButton_7);
		
img =new ImageIcon(getClass().getResource("main.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(1000, 500, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
	}
}
