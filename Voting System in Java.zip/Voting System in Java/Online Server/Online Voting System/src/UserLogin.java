import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Statement;

public class UserLogin extends VotingDemo1{

	
	String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
	ResultSet r=null;
	PreparedStatement st=null;
	
	
	UserLogin(String username,String pass1){
		
		
		try {
			
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url, user, pass);
			
		
		java.sql.Statement st=con.createStatement();
			
			
			String s="select *from signup where UserName='"+username+"' and Pass='"+pass1+"'  ";
			
			r=st.executeQuery(s);
			
		
			
			if(r.next()) {
				
				
				String id=r.getString("IdNumber");
				
				PasswordChange passwordchange=new PasswordChange(id);
				UserProfileView userProfileView =new UserProfileView(id);
				Vote vote=new Vote(id,username);
				UserSwing usr=new UserSwing(id);
				
				UserSwing u=new UserSwing();
				u.setVisible(true);
				
				
			}
			
			else {
				
				
                ConfirmUserSwing confirmUserSwing =new ConfirmUserSwing();
				
				confirmUserSwing.setVisible(true);
				JOptionPane.showMessageDialog(null, "YOUR USENAME OR PASSWORD IS INCORRECT", "WARNING", 1);
			}
			
			
			
			
			}
			
			catch(Exception e) {
				
				System.out.println("Exception caught"+e);
			}
		
		
		
		
	}
	
	
	
}
