import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class UserProfileView extends VotingDemo1{

	private JPanel contentPane;

	String url="jdbc:mysql://sql12.freemysqlhosting.net:3306/sql12232086";
	String user ="sql12232086";
	String pass="icQsWcmiEZ";
	String driver="com.mysql.jdbc.Driver";
	
	
	static String e,f;
	
	
	
	
public UserProfileView(String id) {
		
	
		
		
		e=id;
		
		
		
	}
		
	
	private ImageIcon img,img1;
	private JLabel jl;
	
	
	public UserProfileView() {
		

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 100, 730, 550);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(176, 224, 230));
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel add = new JLabel("Address      :");
		add.setForeground(Color.CYAN);
		add.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		add.setBounds(356, 282, 111, 14);
		contentPane.add(add);
		
		JLabel gen = new JLabel("Gender        :");
		gen.setForeground(Color.CYAN);
		gen.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		gen.setBounds(360, 208, 93, 14);
		contentPane.add(gen);
		
		JLabel id = new JLabel("ID Number        :");
		id.setForeground(Color.CYAN);
		id.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		id.setBounds(22, 127, 132, 14);
		contentPane.add(id);
		
		JLabel fname = new JLabel("Full Name         :");
		fname.setForeground(Color.CYAN);
		fname.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		fname.setBounds(22, 214, 132, 14);
		contentPane.add(fname);
		
		JLabel uname = new JLabel("User Name        :");
		uname.setForeground(Color.CYAN);
		uname.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		uname.setBounds(22, 291, 132, 14);
		contentPane.add(uname);
		
		JLabel faname = new JLabel("Father's Name  :");
		faname.setForeground(Color.CYAN);
		faname.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		faname.setBounds(22, 362, 132, 14);
		contentPane.add(faname);
		
		JLabel mname = new JLabel("Mother's Name :");
		mname.setForeground(Color.CYAN);
		mname.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		mname.setBounds(22, 427, 139, 14);
		contentPane.add(mname);
		
		JLabel age = new JLabel("Age              :");
		age.setForeground(Color.CYAN);
		age.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		age.setBounds(356, 125, 97, 19);
		contentPane.add(age);
		
		JButton back = new JButton("Back");
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				UserSwing userswing=new UserSwing();
				userswing.setVisible(true);
				
			}
		});
		back.setForeground(Color.blue);
		back.setCursor(cursor);
		back.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		back.setBounds(485, 450, 89, 23);
		contentPane.add(back);
		
		JLabel lblH = new JLabel("");
		lblH.setForeground(Color.RED);
		lblH.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblH.setBounds(145, 127, 165, 19);
		contentPane.add(lblH);
		
		JLabel lblFullName = new JLabel("");
		lblFullName.setForeground(new Color(255, 0, 0));
		lblFullName.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblFullName.setBounds(145, 214, 190, 20);
		contentPane.add(lblFullName);
		
		JLabel lblUsername = new JLabel("");
		lblUsername.setForeground(new Color(255, 0, 0));
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblUsername.setBounds(153, 292, 193, 23);
		contentPane.add(lblUsername);
		
		JLabel lblFathername = new JLabel("");
		lblFathername.setForeground(new Color(255, 0, 0));
		lblFathername.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblFathername.setBounds(158, 362, 177, 19);
		contentPane.add(lblFathername);
		
		JLabel lblMothername = new JLabel("");
		lblMothername.setForeground(new Color(255, 0, 0));
		lblMothername.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblMothername.setBounds(149, 427, 186, 23);
		contentPane.add(lblMothername);
		
		JLabel lblAge = new JLabel("");
		lblAge.setForeground(new Color(255, 0, 0));
		lblAge.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAge.setBounds(463, 125, 165, 19);
		contentPane.add(lblAge);
		
		JLabel lblGender = new JLabel("");
		lblGender.setForeground(new Color(255, 0, 0));
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblGender.setBounds(459, 208, 177, 20);
		contentPane.add(lblGender);
		
		JLabel lblAddress = new JLabel("");
		lblAddress.setForeground(new Color(255, 0, 0));
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAddress.setBounds(459, 282, 235, 23);
		contentPane.add(lblAddress);
		
		JLabel lblNewLabel = new JLabel("Profile");
		lblNewLabel.setForeground(Color.CYAN);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBounds(241, 37, 190, 39);
		contentPane.add(lblNewLabel);
		
img =new ImageIcon(getClass().getResource("sub.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(730, 550, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
		
		
		try {
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url, user, pass);
			
		
		     
			
		     
			
			String s="select *from signup where IdNumber='"+e+"'  ";
			
			Statement st=(Statement) con.createStatement();
			
			ResultSet r=st.executeQuery(s);
			while(r.next()) {
				
				lblH.setText(r.getString("IdNumber"));
				lblFullName.setText(r.getString("FullName"));
				lblUsername.setText(r.getString("UserName"));
				lblFathername.setText(r.getString("FatherName"));
				lblMothername.setText(r.getString("MotherName"));
				 lblAge.setText(r.getString("Age"));
				 lblAddress.setText(r.getString("Address"));
				 lblGender.setText(r.getString("Gender"));
				
			}
				
			
			
			
			
			
	}

	catch(Exception e) {
		System.out.println("exception caught in "+e);
	}
		
		
		
		
	}
	
	

	
		
		
		
		
		
		
	
}







