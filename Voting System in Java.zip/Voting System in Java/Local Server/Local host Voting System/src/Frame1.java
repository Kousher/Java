import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Frame1 extends JFrame {

	private JPanel contentPane;
	private Cursor cursor;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame1 frame = new Frame1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

public void cursors() {
		
		cursor=new Cursor(cursor.HAND_CURSOR);	
		
}
private JLabel jl;
private JButton jb;
private ImageIcon img,img1;

public Frame1() {
		
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 100, 782, 390);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Admin");
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				dispose();
				ConfirmAdminSwing confirmAdminSwing =new ConfirmAdminSwing();
				confirmAdminSwing.setVisible(true);
				
				
				
			}
		});
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.setBounds(194, 140, 127, 51);
		//btnNewButton.setBackground(Color.white);
		btnNewButton.setCursor(cursor);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("User");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				ConfirmUserSwing confirmUserSwing =new ConfirmUserSwing();
				
				confirmUserSwing.setVisible(true);
				
				
				
			}
		});
		btnNewButton_1.setForeground(new Color(25, 25, 112));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setBounds(443, 140, 127, 51);
		btnNewButton_1.setCursor(cursor);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel(" Login");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setBounds(324, 24, 127, 61);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("  As");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_1.setForeground(Color.white);
		lblNewLabel_1.setBounds(334, 77, 84, 45);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				VotingDemo1 vooo=new VotingDemo1();
				vooo.setVisible(true);
				
			}
		});
		btnNewButton_2.setForeground(new Color(25, 25, 112));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setBounds(334, 240, 102, 51);
		contentPane.add(btnNewButton_2);
img =new ImageIcon(getClass().getResource("r.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(782, 390, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
		
		
	}
}
