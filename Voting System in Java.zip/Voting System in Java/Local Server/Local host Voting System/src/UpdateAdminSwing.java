import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Cursor;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class UpdateAdminSwing extends JFrame {

	private JPanel contentPane;
	public Cursor cursor;
	private JTextField textFields;
	private JTextField textFields_1;
	private JTextField textFields_2;
	private JTextField textFields_3;
	private JTextField textFields_8;
	private JTextField textFields_9;
	private JTextField textFields_10;
	private JTextField textField_11;
	private JTable table;
	String url="jdbc:mysql://localhost:3306/database";
	String user ="root";
	String pass="171-15-9084";
	String driver="com.mysql.jdbc.Driver";
	private JTextField textField;
	int i;
	
	
	
public void cursors() {
		
		cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
	public static void main(String[] args) {
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					
					UpdateAdminSwing frame = new UpdateAdminSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 */
	private ImageIcon img1,img;
	private JLabel jl;
	public UpdateAdminSwing() {
		

	
		
		
		cursor=new Cursor(cursor.HAND_CURSOR);
		
		
		
		setTitle("UPDATE");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 70, 800, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Full Name           :");
		lblNewLabel.setForeground(Color.CYAN);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(51, 162, 130, 26);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("User Name         :");
		lblNewLabel_1.setForeground(Color.CYAN);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(51, 219, 130, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Father's Name  :");
		lblNewLabel_2.setForeground(Color.CYAN);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(55, 265, 141, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Mother's Name :");
		lblNewLabel_3.setForeground(Color.CYAN);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_3.setBounds(51, 317, 130, 14);
		contentPane.add(lblNewLabel_3);
		
		textFields = new JTextField();
		textFields.setFont(new Font("Tahoma", Font.BOLD, 15));
		textFields.setBounds(218, 153, 181, 33);
		contentPane.add(textFields);
		textFields.setColumns(10);
		
		textFields_1 = new JTextField();
		textFields_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		textFields_1.setBounds(218, 210, 181, 33);
		contentPane.add(textFields_1);
		textFields_1.setColumns(10);
		
		textFields_2 = new JTextField();
		textFields_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		textFields_2.setBounds(218, 256, 181, 33);
		contentPane.add(textFields_2);
		textFields_2.setColumns(10);
		
		textFields_3 = new JTextField();
		textFields_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		textFields_3.setBounds(218, 308, 181, 33);
		contentPane.add(textFields_3);
		textFields_3.setColumns(10);
		
		JLabel label = new JLabel("Age                      :");
		label.setForeground(Color.CYAN);
		label.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label.setBounds(441, 156, 130, 26);
		contentPane.add(label);
		
		textFields_8 = new JTextField();
		textFields_8.setFont(new Font("Tahoma", Font.BOLD, 15));
		textFields_8.setColumns(10);
		textFields_8.setBounds(593, 153, 181, 33);
		contentPane.add(textFields_8);
		
		JLabel label_1 = new JLabel("Address             :");
		label_1.setForeground(Color.CYAN);
		label_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_1.setBounds(441, 210, 130, 14);
		contentPane.add(label_1);
		
		textFields_9 = new JTextField();
		textFields_9.setFont(new Font("Tahoma", Font.BOLD, 15));
		textFields_9.setColumns(10);
		textFields_9.setBounds(593, 200, 181, 33);
		contentPane.add(textFields_9);
		
		JLabel label_2 = new JLabel("Gender               :");
		label_2.setForeground(Color.CYAN);
		label_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		label_2.setBounds(441, 256, 130, 14);
		contentPane.add(label_2);
		
		textFields_10 = new JTextField();
		textFields_10.setFont(new Font("Tahoma", Font.BOLD, 15));
		textFields_10.setColumns(10);
		textFields_10.setBounds(593, 247, 181, 33);
		contentPane.add(textFields_10);
		
		
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
				Class.forName(driver);
				Connection con1=DriverManager.getConnection(url, user, pass);
				
				String fullname=textFields.getText();
				String uname=textFields_1.getText();
				String fname=textFields_2.getText();
				String mname=textFields_3.getText();
				String age=textFields_8.getText();
				String address=textFields_9.getText();
				String gender=textFields_10.getText();
				
				
				String s1="update database.signup  set FullName='"+fullname+"' , UserName='"+uname+"', FatherName='"+fname+"',MotherName='"+mname+"',Age='"+age+"', Address='"+address+"'  ,Gender='"+gender+"' where IdNumber='"+i+"' "    ;
				
				Statement 	st3=con1.createStatement();
			
					
					 st3.executeUpdate(s1);
					 JOptionPane.showMessageDialog(null, "YOUR UPDATE IS COMPLETE", "UPDATE", -1);
				
				}
				catch(Exception e3) {
					System.out.println("Exception caught in "+e3);
				}
				
				
				
			}
		});
		btnNewButton.setForeground(Color.blue);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setBounds(51, 375, 89, 42);
		btnNewButton.setCursor(cursor);
		
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Show");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					
					String s2=textField.getText();
					
					Class.forName(driver);
					Connection con1=DriverManager.getConnection(url, user, pass);
					
					String s1="select IdNumber,FullName,UserName,FatherName,MotherName,Age,Address,Gender from database.signup  where IdNumber='"+s2+"' ";
					
				Statement 	st1=con1.createStatement();
			
					
					ResultSet rs1=	st1.executeQuery(s1);
						
						table.setModel(DbUtils.resultSetToTableModel(rs1));
					
						
						
						
					} catch (Exception e1) {
						System.out.println("Exception caught "+e1);
					}
				
				
				
				
				
			}
		});
		btnNewButton_1.setForeground(Color.blue);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBounds(603, 54, 113, 40);
		btnNewButton_1.setCursor(cursor);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		
		scrollPane.setBounds(51, 457, 723, 69);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				

				
				
       try {
					
					Class.forName(driver);
					Connection con1=DriverManager.getConnection(url, user, pass);

					int row=table.getSelectedRow();
					
					String Idnumber1=(table.getModel().getValueAt(row, 0).toString());
					
					String s2="select *from database.signup where IdNumber='"+Idnumber1+"'  ";
					
				Statement 	st2=con1.createStatement();
			
					
					ResultSet rs2=	st2.executeQuery(s2);
						
					while(rs2.next()) {
						
						i=Integer.parseInt(rs2.getString("IdNumber"));
						textFields.setText(rs2.getString("FullName"));
						textFields_1.setText(rs2.getString("UserName"));
						textFields_2.setText(rs2.getString("FatherName"));
						textFields_3.setText(rs2.getString("MotherName"));
						textFields_8.setText(rs2.getString("Age"));
						textFields_9.setText(rs2.getString("Address"));
						textFields_10.setText(rs2.getString("Gender"));
						
						
						
						
						
						
						
					}
						
					
						
						
						
					} catch (Exception e1) {
						System.out.println("Exception caught "+e1);
					}
				
				
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				AdminSwing addm=new AdminSwing();
				addm.setVisible(true);
				
				
				
			}
		});
		btnNewButton_2.setForeground(Color.blue);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_2.setBounds(355, 382, 89, 35);
		btnNewButton_2.setCursor(cursor);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_4 = new JLabel("Enter Search Id    :");
		lblNewLabel_4.setForeground(Color.cyan);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_4.setBounds(182, 54, 149, 33);
		contentPane.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setForeground(new Color(25, 25, 112));
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setBounds(341, 56, 198, 33);
		contentPane.add(textField);
		textField.setColumns(10);
img =new ImageIcon(getClass().getResource("sub.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(800, 600, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
		
	}
}
