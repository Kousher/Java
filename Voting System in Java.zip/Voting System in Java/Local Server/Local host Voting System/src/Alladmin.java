
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Alladmin extends JFrame{


	private JPanel contentPane;
	private JTextField textField;
	private Cursor cursor;
	
	
	
	String url="jdbc:mysql://localhost:3306/database";
	String user="root";
	String pass="171-15-9084";
	String driver="com.mysql.jdbc.Driver";
	ResultSet r=null;
	PreparedStatement st=null;
	
	Alladmin(){
		
		
		
		delete();
	}
	
	private ImageIcon img1,img;
	private JLabel jl;
	public void delete() {
		
		try {
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url, user, pass);
				
				
			
		
	cursor=new Cursor(cursor.HAND_CURSOR);
		
		
		
		setTitle("DELETE");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID Number:");
		lblNewLabel.setForeground(Color.cyan);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBounds(44, 99, 197, 51);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(222, 113, 167, 35);
		textField.setForeground(new Color(25, 25, 112));
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("DELETE");
		btnNewButton.setForeground(Color.blue);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		btnNewButton.setBounds(233, 191, 144, 30);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i=Integer.parseInt(textField.getText());
				
    
				
				
				
 try {
	 
	 
					Class.forName(driver);
					Connection con=DriverManager.getConnection(url, user, pass);
					
                 Statement st3=con.createStatement();
					
					String s3="select *from signup where IdNumber ='"+i+"' ";
					
				ResultSet	rs3=st3.executeQuery(s3);
				
				if(rs3.next()) {
					
					
					
				
				
				
				String s="Delete from database.signup where IdNumber ='"+i+"'  ";
				
			Statement 	st=con.createStatement();
		
				
					st.executeUpdate(s);
					
					JOptionPane.showMessageDialog(null,"Delete Successfully","Delete",JOptionPane.PLAIN_MESSAGE);
				}
				
				else {
					
					JOptionPane.showMessageDialog(null,"Please Enter Valid ID","Delete",JOptionPane.PLAIN_MESSAGE);
					
				}
				
				} 
 
                catch ( Exception e1) {
					System.out.println("Exception caught "+e1);
				} 
				
 
			}
		});
		
		
		
		btnNewButton.setCursor(cursor);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Log Out");
		btnNewButton_1.setForeground(Color.blue);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setBounds(59, 356, 129, 35);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				VotingDemo1 vote=new VotingDemo1();
				vote.setVisible(true);
			
				
			}
				
		});
		
		
		
		
		
		btnNewButton_1.setCursor(cursor);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setForeground(Color.blue);
		btnNewButton_2.setBounds(302, 356, 115, 35);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				dispose();
			AdminSwing as=new AdminSwing();
			as.setVisible(true);
			
				
			}
				
		});
		
		
		btnNewButton_2.setCursor(cursor);
		contentPane.add(btnNewButton_2);
		
		
		JButton btnNewButton_3 = new JButton("Exit");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_3.setForeground(Color.blue);
		btnNewButton_3.setBounds(538, 356, 109, 35);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			
				
			}
				
		});
		
		
		btnNewButton_3.setCursor(cursor);
		contentPane.add(btnNewButton_3);
img =new ImageIcon(getClass().getResource("bd1.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(700, 500, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
		
		
		
		
			
			
			
			
		}
		catch(Exception e) {
			
			System.out.println("Exception caught "+e);
			
		}
	}
	
	
	
	
	
}


