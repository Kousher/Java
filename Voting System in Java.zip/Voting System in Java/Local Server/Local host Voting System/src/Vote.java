import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ImageIcon;

public class Vote extends VotingDemo1 {
    private ButtonGroup bg=new ButtonGroup();
	private JPanel contentPane;
	String url="jdbc:mysql://localhost:3306/database";
	String user ="root";
	String pass="171-15-9084";
	String driver="com.mysql.jdbc.Driver";
	
	String v=null;
	static String i,u;

	public Vote(String id,String username) {
		
		i=id;
		u=username;
	}
	
	
	
	public Vote() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 100, 650, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("The ballot is stronger than the bullet.");
		lblNewLabel.setForeground(Color.magenta);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBounds(71, 54, 552, 32);
		contentPane.add(lblNewLabel);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Awami Leauge");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				 v="A";
				
				
			}
		});
		rdbtnNewRadioButton.setCursor(cursor);
		rdbtnNewRadioButton.setForeground(new Color(25, 25, 112));
		rdbtnNewRadioButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		rdbtnNewRadioButton.setBounds(24, 148, 133, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("National Party");
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				 v="N";
			}
		});
		rdbtnNewRadioButton_1.setCursor(cursor);
		rdbtnNewRadioButton_1.setForeground(new Color(25, 25, 112));
		rdbtnNewRadioButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		rdbtnNewRadioButton_1.setBounds(179, 148, 145, 23);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("BNP");
		rdbtnNewRadioButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
			 v="B";
			}
		});
		rdbtnNewRadioButton_2.setCursor(cursor);
		rdbtnNewRadioButton_2.setForeground(new Color(25, 25, 112));
		rdbtnNewRadioButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		rdbtnNewRadioButton_2.setBounds(347, 148, 109, 23);
		contentPane.add(rdbtnNewRadioButton_2);
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("N/A");
		rdbtnNewRadioButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				 v="N/A";
				
			}
		});
		rdbtnNewRadioButton_3.setCursor(cursor);
		rdbtnNewRadioButton_3.setForeground(new Color(25, 25, 112));
		rdbtnNewRadioButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		rdbtnNewRadioButton_3.setBounds(490, 150, 109, 23);
		contentPane.add(rdbtnNewRadioButton_3);
		
		bg.add(rdbtnNewRadioButton);
		bg.add(rdbtnNewRadioButton_1);
		bg.add(rdbtnNewRadioButton_2);
		bg.add(rdbtnNewRadioButton_3);
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				int ij=JOptionPane.showConfirmDialog(null, "Are You Confirm","confarmation",JOptionPane.YES_NO_OPTION);
				if(ij==0) {
				if(v==null) {
					
					
					JOptionPane.showMessageDialog(null, "Please Select Any Candidate","Warning",1);
					
				}
				else {
				try {
					Class.forName(driver);
					Connection con=DriverManager.getConnection(url, user, pass);
					
					
				
					
					String ad="insert into vote (idvote , name , party) values(?,?,?) ";
					
					PreparedStatement st=(PreparedStatement) con.prepareStatement(ad);
					
					st.setString(1,i);
					st.setString(2,u);
					st.setString(3,v);
					
					st.executeUpdate();
					
					dispose();
					UserSwing us1=new UserSwing();
					us1.setVisible(true);
					
					JOptionPane.showMessageDialog(null, "Thank You.Your Vote is Complete","Welcome",JOptionPane.INFORMATION_MESSAGE);
					
				}
				
				catch(Exception e) {
					
					System.out.println("Exception caught in"+e);
				}}
				
				
				}
				
				else {
					
				}
			}
		});
		btnNewButton.setCursor(cursor);
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(248, 218, 89, 32);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				UserSwing s=new UserSwing();
				s.setVisible(true);
				
				
			}
		});
		btnNewButton_1.setForeground(new Color(25, 25, 112));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(24, 399, 89, 32);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0);
				
			}
		});
		btnNewButton_2.setForeground(new Color(25, 25, 112));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(490, 399, 89, 32);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(Vote.class.getResource("/images/vote.jpg")));
		lblNewLabel_1.setBounds(0, 0, 624, 461);
		contentPane.add(lblNewLabel_1);
	}
}
