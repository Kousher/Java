import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class SignupFrameSwing extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JButton btnNewButton;
	private Cursor cursor;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JPasswordField passwordField;

	String url="jdbc:mysql://localhost:3306/database";
	String user ="root";
	String pass="171-15-9084";
	String driver="com.mysql.jdbc.Driver";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					SignupFrameSwing frame = new SignupFrameSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

public void cursors() {
		
		cursor=new Cursor(cursor.HAND_CURSOR);
		
	}
private ImageIcon img,img1;
private JLabel jl;
	public SignupFrameSwing() {
		
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 60, 950, 650);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		 
		
		JLabel lblNewLabel_1 = new JLabel("Full Name          :");
		lblNewLabel_1.setForeground(Color.CYAN);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(46, 101, 132, 33);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("User Name        :");
		lblNewLabel_2.setForeground(Color.CYAN);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_2.setBounds(46, 164, 132, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Father's Name :");
		lblNewLabel_3.setForeground(Color.CYAN);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_3.setBounds(46, 208, 132, 34);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Mother's Name:");
		lblNewLabel_4.setForeground(Color.CYAN);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_4.setBounds(46, 266, 132, 33);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Age                     :");
		lblNewLabel_5.setForeground(Color.CYAN);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_5.setBounds(46, 310, 132, 52);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Address             :");
		lblNewLabel_6.setForeground(Color.CYAN);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_6.setBounds(46, 373, 143, 45);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Gender              :");
		lblNewLabel_7.setForeground(Color.CYAN); 
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_7.setBounds(46, 435, 132, 31);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Password         :");
		lblNewLabel_8.setForeground(Color.CYAN);
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_8.setBounds(46, 495, 137, 14);
		contentPane.add(lblNewLabel_8);
		
		textField = new JTextField();
		textField.setForeground(new Color(25, 25, 112));
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setBounds(201, 105, 277, 28);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setForeground(new Color(25, 25, 112));
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_1.setBounds(201, 159, 277, 28);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setForeground(new Color(25, 25, 112));
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_2.setBounds(201, 213, 277, 29);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setForeground(new Color(25, 25, 112));
		textField_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_3.setBounds(201, 270, 277, 28);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setForeground(new Color(25, 25, 112));
		textField_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_4.setBounds(201, 323, 277, 31);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_5.setForeground(new Color(25, 25, 112));
		textField_5.setBounds(199, 377, 279, 33);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setForeground(new Color(25, 25, 112));
		textField_6.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_6.setBounds(201, 439, 277, 27);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setForeground(new Color(25, 25, 112));
		passwordField.setFont(new Font("Tahoma", Font.BOLD, 15));
		passwordField.setBounds(201, 486, 277, 28);
		contentPane.add(passwordField);
		
		
		
		btnNewButton = new JButton("EXIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnNewButton.setForeground(Color.blue);
		btnNewButton.setCursor(cursor);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.setBounds(757, 502, 117, 45);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Submit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				String FullName=textField.getText();
				String UserName=textField_1.getText();
				String FatherName=textField_2.getText();
				String MotherName=textField_3.getText();
				String Age=textField_4.getText();
				String Address=textField_5.getText();
				String Gender=textField_6.getText();
				String Pass=passwordField.getText();
				
				if(textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() || textField_3.getText().isEmpty()  || textField_4.getText().isEmpty()  ||  textField_5.getText().isEmpty()  || textField_6.getText().isEmpty() ||  passwordField.getText().isEmpty()) {
					
					
					JOptionPane.showMessageDialog(null, "Please Enter All the Information Correctly","Caution",2);
					
					
					
					
					
					
					
					
				}
				
				else {
					try {
					Class.forName(driver);
					Connection con=DriverManager.getConnection(url, user, pass);
					
					
					String s3="select *from signup where UserName='"+UserName+"' and Pass='"+Pass+"' ";
					Statement st=(Statement) con.createStatement();
					
					ResultSet rs=st.executeQuery(s3);
					
					if(rs.next()) {
						
						
					JOptionPane.showMessageDialog(null,"You are already exist in Voter List","Warning",JOptionPane.ERROR_MESSAGE);	
						
					}
					
					
					else {
						
						int x=JOptionPane.showConfirmDialog(null,"Do you  want to Submit","Confirmation",JOptionPane.YES_NO_OPTION);
						
						
						if(x==0) {
							
							
							SignUp signup=new SignUp(FullName,UserName,FatherName,MotherName, Age,Address,Gender,Pass);
						}
						
					}
					
					}
					
					catch(Exception e2) {
						System.out.println("Exception caught in"+e2);
					}
					
				
				
				
				
				
				}
				
			
				
				
			}
		});
		btnNewButton_1.setForeground(Color.blue);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setBounds(260, 538, 153, 51);
		btnNewButton_1.setCursor(cursor);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				VotingDemo1 vo2=new VotingDemo1();
				vo2.setVisible(true);
				
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_2.setForeground(Color.blue);
		btnNewButton_2.setBounds(757, 133, 105, 45);
		contentPane.add(btnNewButton_2);
img =new ImageIcon(getClass().getResource("bd1.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(950, 650, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
		
	}
}
