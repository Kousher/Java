import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class ConfirmAdminSwing extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private Cursor cursor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConfirmAdminSwing frame = new ConfirmAdminSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

public void cursors() {
		
		cursor=new Cursor(cursor.HAND_CURSOR);	
		
}
private ImageIcon img1,img;
private JLabel jl;
	public ConfirmAdminSwing() {
		
		cursors();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 100, 700, 500);
		setResizable(false);
		contentPane = new JPanel();
		
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		 
		
		JLabel lblNewLabel_3 = new JLabel("USERNAME:");
		lblNewLabel_3.setForeground(Color.cyan);
		
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel_3.setBounds(29, 65, 150, 43);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setForeground(new Color(25, 25, 112));
		textField.setFont(new Font("Tahoma", Font.BOLD, 20));
		textField.setBounds(201, 65, 178, 35);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("PASSWORD:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		//lblNewLabel_4.setBackground(Color.BLACK);
		lblNewLabel_4.setForeground(Color.cyan);
		lblNewLabel_4.setBounds(29, 146, 170, 34);
		contentPane.add(lblNewLabel_4);
		
		
		passwordField = new JPasswordField();
		passwordField.setForeground(Color.black);
		passwordField.setFont(new Font("Tahoma", Font.BOLD, 20));
		passwordField.setBounds(201, 146, 178, 34);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.setForeground(Color.blue);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.setBounds(210, 219, 156, 43);
		btnNewButton.setCursor(cursor);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				String un=textField.getText();
				String pas=passwordField.getText();
				/*if(un.isEmpty()) {
					ConfirmAdminSwing o=new ConfirmAdminSwing();
					o.setVisible(true);
					
					JOptionPane.showMessageDialog(null, "You didn't enter anything in Username");
				}
				
				
				
                      if(pas.isEmpty()) {
                    	  ConfirmAdminSwing ob=new ConfirmAdminSwing();
          				ob.setVisible(true);
					
					JOptionPane.showMessageDialog(null, "You didn't enter anything in Password");
				}*/
                      
				      dispose();
                      Login lg=new Login(un,pas);
				
				
				
				
			}
		});
		
		
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Main Menu");
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				VotingDemo1 vo1=new VotingDemo1();
				vo1.setVisible(true);
				
			}
		});
		btnNewButton_1.setForeground(Color.blue);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setBounds(516, 219, 150, 45);
		contentPane.add(btnNewButton_1);
		
img =new ImageIcon(getClass().getResource("bd.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(700, 500, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
	}
}
