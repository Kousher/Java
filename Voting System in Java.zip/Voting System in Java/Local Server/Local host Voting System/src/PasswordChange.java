import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class PasswordChange extends VotingDemo1 {

	private JPanel contentPane;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
    static String p;
	
    String url="jdbc:mysql://localhost:3306/database";
	String user ="root";
	String pass="171-15-9084";
	String driver="com.mysql.jdbc.Driver";
	ResultSet r=null;
	PreparedStatement st=null;
	
	
	public PasswordChange(String id) {
		
		
		p=id;
		
	}
	private ImageIcon img1,img;
	private JLabel jl;

	public PasswordChange() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 650, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(176, 224, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Your Old Password :");
		lblNewLabel.setForeground(Color.cyan);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(25, 69, 280, 33);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Your New Password :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_1.setForeground(Color.cyan);
		lblNewLabel_1.setBounds(25, 130, 280, 25);
		contentPane.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setForeground(new Color(25, 25, 112));
		passwordField.setFont(new Font("Tahoma", Font.BOLD, 20));
		passwordField.setBounds(311, 74, 214, 25);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setForeground(new Color(25, 25, 112));
		passwordField_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		passwordField_1.setBounds(315, 130, 210, 26);
		contentPane.add(passwordField_1);
		
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
				Class.forName(driver);
				Connection con=DriverManager.getConnection(url, user, pass);
				
				
			String pa=passwordField.getText(); 
				
			String ac="select *from signup where IdNumber='"+p+"' and Pass='"+pa+"' ";
			
			Statement st=(Statement) con.createStatement();
			
			ResultSet rs=st.executeQuery(ac);
			
			if(rs.next()) {
				String pa1=passwordField_1.getText();
				
				String ac1="update  signup set Pass='"+pa1+"' where IdNumber='"+p+"' ";
				
				Statement st1=(Statement) con.createStatement();
				
				st1.executeUpdate(ac1);
				 JOptionPane.showMessageDialog(null, "YOUR PASSWORD CHANGE SUCCESSFULLY", "UPDATE", -1);
				
				
			}
			
			else {
				JOptionPane.showMessageDialog(null, "Please Enter Correct Password", "UPDATE", -1);
				
			}
			
			
				}
				catch(Exception e) {
					System.out.println("Exception caught in"+e);
				}
				
				
				
			}
		});
		btnNewButton.setCursor(cursor);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 19));
		btnNewButton.setForeground(Color.blue);
		btnNewButton.setBounds(227, 207, 103, 33);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setCursor(cursor);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				dispose();
				UserSwing n=new UserSwing();
				n.setVisible(true);
				
			}
		});
		btnNewButton_1.setForeground(Color.BLUE);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 19));
		btnNewButton_1.setBounds(32, 306, 89, 33);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.setCursor(cursor);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0);
				
			}
		});
		btnNewButton_2.setForeground(Color.BLUE);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 19));
		btnNewButton_2.setBounds(510, 306, 89, 33);
		contentPane.add(btnNewButton_2);
img =new ImageIcon(getClass().getResource("sub.jpg"));
		
		Image im=img.getImage();
		Image imm=im.getScaledInstance(700, 500, Image.SCALE_SMOOTH);
		img1=new ImageIcon(imm);
		jl=new JLabel(img1);
		jl.setBounds(0,0,img1.getIconWidth(),img1.getIconHeight());
		contentPane.add(jl);
		
	}
}
